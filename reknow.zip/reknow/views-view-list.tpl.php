<?php if (!empty($title)) : ?>
<h2><?php print $title; ?></h2>
<?php endif; ?>
<ul class="list-unstyled">
<?php foreach ($rows as $id => $row): ?>
	<li class="<?php print $classes_array[$id]; ?>"><?php print $row; ?></li>
<?php endforeach; ?>
</ul>