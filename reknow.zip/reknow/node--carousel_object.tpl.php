<?php if ($teaser): ?>
    <img src="<?php print $node->field_img['und'][0]['uri']; ?>">
    <div class="carousel-caption">
        <?php print $node->body["und"][0]["value"]; ?>
    </div>
<?php else: ?>
    <div class="carousel-image" style="background-image:url(<?php print file_create_url($node->field_img['und'][0]['uri']); ?>)">
    </div>
    <div class="carousel-caption">
        <?php print $node->body["und"][0]["value"]; ?>
    </div>
<?php endif; ?>