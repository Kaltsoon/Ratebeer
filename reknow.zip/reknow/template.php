<?php 
	function reknow_links__system_main_menu($variables) {
		$output="";
		foreach ($variables['links'] as $link) {
			$class="";
			if(current_path()==$link['href'] || ($link['title']=="Home" && drupal_is_front_page())){
				$class=" class='active'";
			}
			$output.="<li".$class.">".l($link['title'], $link['href'], $link)."</li>";
		}
		return $output;
	}
?>
