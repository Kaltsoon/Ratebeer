<?php if ($teaser): ?>
    <h3><?php print $title; ?></h3>
    <p class="text-muted">
    	<i class="fa fa-calendar"></i> <?php print format_date($node->created); ?>
   	</p>
    <?php print $node->body["und"][0]["value"]; ?>
    aaa
    <div class="margin-top">
    	<?php print l("More <i class='fa fa-chevron-right fa-sm'></i>", 'node/' . $nid, array('attributes' => array('class' => t('btn btn-default')), 'html' => true)); ?>
    </div>
<?php else: ?>
    <h3><?php print $title; ?></h3>
	<p class="text-muted">
		<i class="fa fa-calendar"></i> <?php print format_date($node->created); ?>
	</p>
    <?php print $node->body["und"][0]["value"]; ?>
    <?php if (user_access('administer nodes')): ?>
    <p class="margin-top">
        <?php print l("<i class='fa fa-pencil' style='margin-right: 6px'></i>Edit", 'node/' . $nid . '/edit', array('html' => true)); ?>
    </p>
    <?php endif; ?>
<?php endif; ?>