  <div id="page-container">
    <div id="header-container">
      <div class="wrapper">
        <nav class="navbar navbar-default" role="navigation">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
              <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="<?php echo $base_path; ?>">
              <img src="<?php echo $base_path.'/'.path_to_theme().'/'; ?>images/logo.jpg" style="float: left">
            </a>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
              <?php print theme('links__system_main_menu', array(
                'links' => $main_menu,
                'attributes' => array(
                  'id' => 'main-menu-links',
                  'class' => array('links', 'clearfix'),
                ),
                'heading' => array(
                  'text' => t('Main menu'),
                  'level' => 'h2',
                  'class' => array('element-invisible'),
                ),
                )); 
              ?>
            <?php if(!user_is_logged_in()): ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li <?php if(explode("/",current_path())[0]=="user"){ print "class='active'"; } ?>><a href="user"><i class="fa fa-user"></i> Sign in</a></li>
            </ul>
            <?php endif; ?>
          </div>
        </nav>
      </div>
    </div>
    <div id="image-container">
      <div class="wrapper">
        <?php if(drupal_is_front_page()): ?>
          <?php print render($page['carousel']); ?>
        <?php else: ?>
          <?php print render($page['page_image']); ?>
        <?php endif; ?>
      </div>
    </div>
    <div id="content-container">
      <div class="wrapper">
        <div class="box box-full">
            <?php print render($tabs); ?>
            <?php if ($title): ?>
            <h2 class="header">
              <?php print $title; ?>
            </h2>
          <?php endif; ?>
          <?php print render($page['content']); ?>
        </div>
      </div>
    </div>
    <?php if(drupal_is_front_page()): ?>
    <div id="promo-container">
      <div class="wrapper">
        <div class="row">
          <div class="col-md-4">
            <div class="box box-full">
              <div class="promo-circle promo-circle-red">
                <i class="fa fa-group"></i>
              </div>
              <h2>Research groups</h2>
              <div class="text-center">
                <?php 
                  print render($page['promo_left']);
                ?>
              </div>
              <p class="text-center margin-top">
                <a href="research-groups" class="btn btn-default">More <i class="fa fa-sm fa-chevron-right"></i></a>
              </p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="box box-full">
              <div class="promo-circle promo-circle-blue">
                <i class="fa fa-archive"></i>
              </div>
              <h2>Publications and software</h2>
              <div class="text-center">
                <?php
                  print render($page['promo_middle']);
                ?>
              </div>
              <p class="text-center margin-top">
                <a href="publications-and-software" class="btn btn-default">More <i class="fa fa-sm fa-chevron-right"></i></a>
              </p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="box box-full">
              <div class="promo-circle promo-circle-green">
                <i class="fa fa-exclamation"></i>
              </div>
              <h2>News and events</h2>
              <div class="text-center">
                <?php print render($page['promo_right']); ?>
              </div>
              <p class="text-center margin-top">
                <a href="news-and-events" class="btn btn-default">More <i class="fa fa-sm fa-chevron-right"></i></a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <div id="footer-container">
      <div class="wrapper">
        <div class="row">
          <div class="col-md-6">
            <?php
              print render($page['footer_contact']);
            ?>
          </div>
          <div class="col-md-6">
          <a href="http://www.ttl.fi/en/Pages/default.aspx" target="blank">
            <img src="<?php echo $base_path.'/'.path_to_theme().'/'; ?>images/footer_logo2.png" class="footer-logo">
          </a>
          <a href="http://www.hiit.fi/fi" target="blank">
            <img src="<?php echo $base_path.'/'.path_to_theme().'/'; ?>images/footer_logo1.png" class="footer-logo">
          </a>
        </div>
      </div>
    </div>
  </div>